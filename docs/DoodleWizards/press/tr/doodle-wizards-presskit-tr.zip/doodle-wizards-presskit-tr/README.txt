RippleBitGames'ten Doodle Wizards basın kiti.
Oyun künyesi, tanıtım ve iletişim: https://ripplebitgames.com/DoodleWizards/press/tr/
