Kit de prensa de Doodle Wizards, de RippleBitGames.
Ficha técnica, descripción y contacto: https://ripplebitgames.com/DoodleWizards/press/es/
