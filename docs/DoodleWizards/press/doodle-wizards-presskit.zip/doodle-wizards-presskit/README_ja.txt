RippleBitGamesによるDoodle Wizardsのプレスキットです。
ファクトシート、ゲーム紹介、連絡先：https://ripplebitgames.com/DoodleWizards/press/ja/
