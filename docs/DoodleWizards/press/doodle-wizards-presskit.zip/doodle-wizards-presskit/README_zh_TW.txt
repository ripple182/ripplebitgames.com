塗鴉法師 Doodle Wizards 媒體資料包，由 RippleBitGames 提供。
遊戲資料、介紹和聯絡方式：https://ripplebitgames.com/DoodleWizards/press/zh_TW/
