Doodle Wizards press kit by RippleBitGames.
Fact sheet, description and contact: https://ripplebitgames.com/DoodleWizards/press/
