Пресс-кит Doodle Wizards от RippleBitGames.
Краткая справка, описание и контакты: https://ripplebitgames.com/DoodleWizards/press/ru/
