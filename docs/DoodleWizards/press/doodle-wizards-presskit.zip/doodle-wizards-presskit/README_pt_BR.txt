Kit de imprensa de Doodle Wizards, da RippleBitGames.
Ficha técnica, descrição e contato: https://ripplebitgames.com/DoodleWizards/press/pt_BR/
